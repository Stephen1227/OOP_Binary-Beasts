package Database;
import java.sql.*;

public class DB_connections {

    public static DB_connections getsconnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    String url="jdbc:sqlserver://DESKTOP-92S6K6R:1433;databaseName=bb;password=DESKTOP-92S6K6R";
     public Connection conn; 
      private DB_connections event;
      public DB_connections(String url,Connection conn,DB_connections event)
      {
          this.url=url;
          this.conn=conn;
          this.event=event;
      }
   
    private DB_connections()
    {
        
        try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
             conn = DriverManager.getConnection(url);
        }
        catch(Exception e)
        {
            System.out.println("Error!!!"+e.getMessage());
        }
       
    } 
         

     }
         
    } 
        

     
    
    

