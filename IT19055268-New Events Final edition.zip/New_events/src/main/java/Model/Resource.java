package Model;
public class Resource 
{

   
    public String Machine_ID;
    public String Machine_name;
    public String Borrowed_By;
    public String Date_Given;
    public String Return_date;
    
    public Resource (String Machine_ID,String Machine_name,String Borrowed_By,String Date_Given,String Return_date)
    {
        this.Machine_ID=Machine_ID;
        this.Machine_name=Machine_name;
        this.Borrowed_By=Borrowed_By;
        this.Date_Given=Date_Given;
        this.Return_date=Return_date;
          
    }

   
    
    public String getmachineid()
    {
        return Machine_ID;
    }
    public String getmachinename()
    {
        return Machine_name ;
    }
    public String getborrowby()
    {
        return Borrowed_By;
    }
    public String getdate()
    {
        return Date_Given;
    }
    public String getr_date()
    {
        return Return_date;
    }

     
   
    @Override
     public String toString()
     {
         return Machine_ID+"\n"+Machine_name+"\n"+Borrowed_By+"\n"+Date_Given+"\n"+Return_date;
     }
     

}


