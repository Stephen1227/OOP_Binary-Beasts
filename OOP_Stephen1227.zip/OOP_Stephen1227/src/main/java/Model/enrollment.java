
package Model;


public class enrollment {
    public String Name;
    public String Email;
    public String Mobile;
    public String Course;
    
    public enrollment(String Name, String Email, String Mobile,String Course ){
        
        this.Name=Name;
        this.Email=Email;
        this.Mobile=Mobile;
        this.Course=Course;
          
    }
    
    public String getName()
    {
        return Name;
    }
    public String getEmail()
    {
        return Email;
    }
    public String getMobile()
    {
        return Mobile;
    }
    public String getCourse()
    {
        return Course;
    }
    public void setName(String Name)
    {
        this.Name=Name; 
    }
     public void setEmail(String Email)
    {
        this.Email=Email; 
    }
     public void setMobile(String Mobile)
    {
        this.Mobile=Mobile; 
    }
     public void setCourse(String Course)
    {
        this.Course=Course; 
    }
     
      @Override
     public String toString()
     {
         return Name+"\n"+Email+"\n"+Mobile+"\n"+Course;
     }
    
}
