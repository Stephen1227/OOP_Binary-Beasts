
package Model;


public class CertificateProgram {
    
}
