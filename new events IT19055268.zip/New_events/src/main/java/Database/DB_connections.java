//import java.sql.Connection;
//import java.sql.DriverManager;
//package Database;
//
//public class DB_connections {
//    
//    final static String JDB ="com.mysql.jdbc.Driver";
//    final static String DBURL="jdbc:mysql://localhost:3306/New_Events";
//     
//   
//    public static DB_connections exception()
//    {
//        try
//        {
//            class.forName(JDB);
//            
//        }
//    }
//    
//}
