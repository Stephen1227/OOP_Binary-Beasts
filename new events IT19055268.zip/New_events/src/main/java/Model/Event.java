package Model;
public class Event 
{
    public String ID;
    public String Name;
    public String Venue;
    public String Time;
    public String s_date;
    public String e_date;
    
    public Event(String ID,String Name,String Venue,String time,String s_date,String e_date)
    {
        this.ID=ID;
        this.Name=Name;
        this.Venue=Venue;
        this.Time=Time;
        this.s_date=s_date;
        this.e_date=e_date;    
    }
    
    public String getid()
    {
        return ID;
    }
    public String getname()
    {
        return Name;
    }
    public String getvenue()
    {
        return Venue;
    }
    public String gettime()
    {
        return Time;
    }
    public String gets_date()
    {
        return s_date;
    }
    public String gete_date()
    {
        return e_date;
    }
    public void setid(String id)
    {
        this.ID=ID; 
    }
     public void setname(String Name)
    {
        this.Name=Name; 
    }
     public void setvenue(String Venue)
    {
        this.Venue=Venue; 
    }
     public void settime(String Time)
    {
        this.Time=Time; 
    }
      public void sets_date(String s_date)
    {
        this.s_date=s_date; 
    }
     public void sete_time(String e_time)
    {
        this.e_date=e_date; 
    }
     
   
    @Override
     public String toString()
     {
         return ID+"\n"+Name+"\n"+Venue+"\n"+Time+"\n"+s_date+"\n"+e_date;
     }
     

}
