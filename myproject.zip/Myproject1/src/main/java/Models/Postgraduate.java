package Models;
public class Postgraduate 
{
    public String course_ID;
    public String course_year;
    public String course_type;
    public String course_description;
    public String course_name;
    public String course_student_id;
    
    public Postgraduate (String course_ID,String course_year,String course_type,String course_description,String course_name,String course_student_id)
    {
        this.course_ID=course_ID;
        this.course_year=course_year;
        this.course_type=course_type;
        this.course_description=course_description;
        this.course_name=course_name;
        this.course_student_id=course_student_id;    
    }
    
    public String getcid()
    {
        return course_ID;
    }
    public String getcoyear()
    {
        return course_year;
    }
    public String getctype()
    {
        return course_type;
    }
    public String getcdiscription()
    {
        return course_description;
    }
    public String getcname()
    {
        return course_name;
    }
    public String getcsid()
    {
        return course_student_id;
    }
    public void setcid(String course_ID)
    {
        this.course_ID=course_ID;
    }
     public void setcoyear(String course_year)
    {
        this.course_year=course_year;
    }
     public void getctype(String course_type)
    {
        this.course_type=course_type;
    }
     public void setcdescription(String course_description)
    {
        this.course_description=course_description;
    }
      public void setcname(String course_name)
    {
        this.course_name=course_name; 
    }
     public void setcsid(String course_student_id)
    {
        this.course_student_id=course_student_id;    
    }
     
   
    @Override
    public String toString()
    {
        return  course_ID+"\n"+course_year+"\n"+course_type+"\n"+course_description+"\n"+course_name+"\n"+course_student_id;
    }
    
     

}