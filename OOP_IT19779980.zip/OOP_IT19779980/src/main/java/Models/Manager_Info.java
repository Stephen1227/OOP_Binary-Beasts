/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author PABASARA PC
 */
public class Manager_Info {

    public String name;
    public int ID;
    public int Telephone;
    private String Address;

    public Manager_Info(String name, int ID, int Telephone, String Address) {
        this.name = name;
        this.ID = ID;
        this.Telephone = Telephone;
        this.Address = Address;
    }

    @Override

    public String toString() {
        return ("Name" + name + "ID" + ID + "Telephone" + Telephone + "Address" + Address);
    }

}
