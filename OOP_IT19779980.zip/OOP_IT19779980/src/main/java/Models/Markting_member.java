/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author PABASARA PC
 */
public class Markting_member {

    public String name;
    private String Adress;
    private int NIC;
    public int Telephone;
    public int ID;

    public Markting_member(String name, String Adress, int NIC, int Telephone, int ID) {
        this.name = name;
        this.Adress = Adress;
        this.NIC = NIC;
        this.Telephone = Telephone;
        this.ID = ID;
    }
    @Override
    
    public String toString()
    {
        return("name "+name +"Address "+Adress+ "NIC" +NIC +"Telephone" +Telephone+ "ID" +ID);
    }
}
