/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
// */
//package service;
//import UI.Event_UI;
//import Database.DB_connections;
//import java.sql.*;
//import javax.swing.*;
//public class testDB 
//{
//    private DB_connections db;
//    public event()
//    {
//        db=DB_connections.getsconnection();
//    }
//    
//    
//}
