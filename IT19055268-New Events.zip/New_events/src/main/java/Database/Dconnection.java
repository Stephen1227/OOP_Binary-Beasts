/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

//import java.sql.*;
//
///**
// *
// * @author GAVEEN MADHAWA
// */
//public class Dconnection {
//         public static DB_connections connect_one()
//     {
//          try{         
//          if (event == null) {              
//              event = new DatabaseConnection();             
//              return instance;          
//          } else if (instance.conn.isClosed()) 
//          {             
//              instance = new DatabaseConnection();             
//              return instance;         
//          } else {             
//              return instance;          
//          }          
//      }catch(SQLException ex)          
//      {              
//          System.out.println("Something Went wrong with server");             
//          return null;          
//
//    
//}
