/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

public class Crew 
{
    public String Crew_ID;
    public String EName;
    public String Supervisor;
    
    public Crew(String Crew_ID,String EName,String Supervisor)
    {
        this.Crew_ID=Crew_ID;
        this.EName=EName;
        this.Supervisor=Supervisor;
        
    }
     public String getcrew_id()
    {
        return Crew_ID;
    }
    public String getname()
    {
        return EName;
    }
    public String getsupervisor()
    {
        return Supervisor;
    }

    @Override
     public String toString()
     {
         return Crew_ID+"\n"+EName+"\n"+Supervisor;
     }
}


 