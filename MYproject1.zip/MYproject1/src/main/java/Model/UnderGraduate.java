
package Model;

/**
 *
 * @author Thilani
 */
public class UnderGraduate {
    
    public String Course_ID;
    public String Course_Name;
    public String Course_Description;
    public String CourseStudent_year;
    public String CourseStudent_ID;
    
public UnderGraduate( String Course_ID,String Course_Name,String Course_Description,String CourseStudent_year,String CourseStudent_ID ){
    
    this.Course_ID = Course_ID;
    this.Course_Name = Course_Name;
    this.Course_Description = Course_Description;
    this.CourseStudent_year = CourseStudent_year;
    this.CourseStudent_ID = CourseStudent_ID;
    
}    
    public String getcourse_id(){
        return Course_ID;
    }
    public String getcourse_name(){
        return Course_Name;
    }   
    public String getcourse_description(){
        return Course_Description;
    }
    public String getcoursestudent_year(){
        return CourseStudent_year;
    }
    public String getcoursestudent_id(){
        return CourseStudent_ID;
    }
    
    @Override 
    public String toString(){
        
        return Course_ID+"\n"+Course_Name+"\n"+Course_Description+"\n"+CourseStudent_year+"\n"+CourseStudent_ID;
        
    }
            
            
}
